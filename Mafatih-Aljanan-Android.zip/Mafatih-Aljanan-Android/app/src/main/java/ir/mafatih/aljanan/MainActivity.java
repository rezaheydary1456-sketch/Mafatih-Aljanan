package ir.mafatih.aljanan;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final String[][] sections = {
        {"اعمال روزانه", "ذکرها و دعاهای هر روز"},
        {"تعقیبات نماز", "دعاها و ذکرهای پس از نماز"},
        {"دعاهای معروف", "گزیده‌ای از دعاهای مشهور"},
        {"زیارات", "زیارت‌نامه‌ها"},
        {"ماه رمضان", "اعمال و دعاهای ماه مبارک رمضان"},
        {"ماه‌های سال", "اعمال ماه‌های قمری"}
    };
    private LinearLayout content;
    private EditText search;
    private int green = Color.rgb(28, 105, 76);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(20, 76, 57));
        getWindow().setNavigationBarColor(Color.rgb(20, 76, 57));
        showHome();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(18, 14, 18, 14);
        return t;
    }

    private LinearLayout base() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setBackgroundColor(Color.rgb(250, 248, 241));
        return page;
    }

    private void showHome() {
        LinearLayout page = base();
        TextView header = text("مفاتیح الجنان", 26, Color.WHITE, true);
        header.setBackgroundColor(green);
        header.setGravity(Gravity.CENTER);
        page.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView intro = text("نسخهٔ آفلاین | متن عربی و فارسی", 15, green, true);
        intro.setGravity(Gravity.CENTER);
        page.addView(intro);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(16);
        search.setHint("جست‌وجو در عنوان‌ها...");
        search.setGravity(Gravity.RIGHT);
        search.setPadding(18, 8, 18, 8);
        page.addView(search, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12, 6, 12, 18);
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
        fillSections("");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { fillSections(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });
    }

    private void fillSections(String query) {
        content.removeAllViews();
        String q = query.trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < sections.length; i++) {
            final int index = i;
            if (!sections[i][0].toLowerCase(Locale.ROOT).contains(q) &&
                !sections[i][1].toLowerCase(Locale.ROOT).contains(q)) continue;
            TextView card = text(sections[i][0] + "\n" + sections[i][1] + "     ←", 18, Color.rgb(45, 55, 48), true);
            card.setBackgroundColor(Color.WHITE);
            card.setElevation(2);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(4, 7, 4, 7);
            content.addView(card, lp);
            card.setOnClickListener(v -> showSection(index));
        }
        if (content.getChildCount() == 0) {
            content.addView(text("موردی پیدا نشد.", 16, Color.DKGRAY, false));
        }
    }

    private void showSection(int index) {
        LinearLayout page = base();
        TextView header = text("‹   " + sections[index][0], 23, Color.WHITE, true);
        header.setBackgroundColor(green);
        page.addView(header);
        header.setOnClickListener(v -> showHome());

        TextView note = text(sections[index][1], 16, green, true);
        page.addView(note);
        TextView body = text(
            "این بخش در نسخهٔ آغازین برنامه آماده شده است.\n\n" +
            "متن کامل و بررسی‌شدهٔ دعاها و زیارت‌نامه‌ها هنوز به این نسخه افزوده نشده است.\n\n" +
            "برای جلوگیری از درج متن نادرست، محتوای کامل پس از تهیهٔ منبع معتبر اضافه خواهد شد.",
            18, Color.rgb(55, 55, 55), false);
        page.addView(body);
        Button back = new Button(this);
        back.setText("بازگشت به فهرست");
        back.setOnClickListener(v -> showHome());
        page.addView(back);
        setContentView(page);
    }
}
